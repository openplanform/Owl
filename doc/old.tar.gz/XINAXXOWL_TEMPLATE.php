<?php

/**
 * XINAX XOWL (Xinax Open Web Library)
 * 
 * Software distribuido bajo la "New BSD License", mas información en /doc/LICENSE
 * 
 * Descripción de la clase
 * 
 * @category XinaxXowl
 * @package XinaxXowl
 * @copyright Copyright (c) 2008-2010 Xinax Software (http://www.xinax.net/)
 * @license New BSD License (http://www.opensource.org/licenses/bsd-license.php)
 * @author Nicolás Palumbo <npalumbo@xinax.net>
 * @version 0.5
 * @since 0.5
 * 
 */

?>
