<?php

/**
 * XINAX CMS
 * 
 * Software bajo licencia de uso. Todos los derechos reservados. El contenido 
 * de este software se encuentra bajo el copyright de XINAX y no debe ser 
 * reproducido en otros sitios webs, listas de correo o cualquier medio de 
 * transmisión electrónica sin poseer la licencia necesaria otorgada por XINAX.
 * 
 * Descripción de la clase
 * 
 * @category XinaxCms
 * @package XinaxCms
 * @copyright Copyright (c) 2008-2010 Xinax Software (http://www.xinax.net/)
 * @license Licencia de uso XinaxCms (http://www.xinax.net/xinaxcms/licencia)
 * @author Nicolás Palumbo <npalumbo@xinax.net>
 * @version 0.5
 * @since 0.5
 * 
 */



?>
